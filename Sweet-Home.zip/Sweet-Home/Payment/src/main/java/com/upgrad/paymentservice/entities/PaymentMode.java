package com.upgrad.paymentservice.entities;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;


public enum PaymentMode {

    UPI("upi"), CARD("card");
	private String text; 
	
	
	
	private PaymentMode(String text) {
		this.text = text;
	}


	@JsonValue
    public String getText(){return this.text;}
	
    @JsonCreator
    public static PaymentMode fromText(String text){
        for(PaymentMode r : PaymentMode.values()){
            if(r.getText().equals(text)){
                return r;
            }
        }
        throw new IllegalArgumentException();
    }

	@Override
	public String toString() {
	    return text;
	}
	
}
