package com.upgrad.paymentservice.dao;

import com.upgrad.paymentservice.entities.PaymentDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentDetailDao extends JpaRepository<PaymentDetailsEntity, Integer> {

}
