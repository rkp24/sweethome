package com.upgrad.paymentservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upgrad.paymentservice.dao.PaymentDetailDao;
import com.upgrad.paymentservice.entities.PaymentDetails;
import com.upgrad.paymentservice.entities.PaymentDetailsEntity;


@Service
public class PaymentService {

	PaymentDetailDao paymentDetailDao;

	@Autowired
	public PaymentService(PaymentDetailDao paymentDetailDao) {
		super();
		this.paymentDetailDao = paymentDetailDao;
	}
	
	
	public int  makePayment(int bookingId, PaymentDetails paymentDetail) {
		PaymentDetailsEntity paymentDetailsEntity = new PaymentDetailsEntity(bookingId, paymentDetail);
		return this.paymentDetailDao.save(paymentDetailsEntity).getBookingId();
	}
	
	public PaymentDetailsEntity getPaymentById(int paymentId) throws Exception {
		Optional<PaymentDetailsEntity> paymentDetailDaoOp=  this.paymentDetailDao.findById(paymentId);
		
		if(paymentDetailDaoOp.isPresent()) {
			return paymentDetailDaoOp.get();
		}else {
			throw new Exception("Payment Id Not Found");
		}
	}
	
}
