package com.upgrad.notificationservice.Entity;

import java.util.Date;

public class BookingInfo_MSG {
	private int bookingId;
	private int userId;
	private Date fromdate;
	private Date toDate;
	
	public BookingInfo_MSG() {
		super();
	}

	public BookingInfo_MSG(int bookingId, int userId, Date fromdate, Date toDate) {
		this.bookingId = bookingId;
		this.userId = userId;
		this.fromdate = fromdate;
		this.toDate = toDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getFromdate() {
		return fromdate;
	}

	public void setFromdate(Date fromdate) {
		this.fromdate = fromdate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	@Override
	public String toString() {
		return "BookingInfo_MSG{" +
				"bookingId=" + bookingId +
				", userId=" + userId +
				", fromdate=" + fromdate +
				", toDate=" + toDate +
				'}';
	}
}
