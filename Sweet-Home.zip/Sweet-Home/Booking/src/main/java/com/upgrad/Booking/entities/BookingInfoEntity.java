package com.upgrad.Booking.entities;
import java.time.Period;
import com.upgrad.Booking.services.BookingServiceImpl;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="booking")
public class BookingInfoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
//    @Column(name = "bookingId")
    private int bookingId;

    @Column(nullable = true,name = "fromDate")
    private LocalDate fromDate;
    @Column(nullable = true,name = "toDate")
    private LocalDate toDate;
    @Column(nullable = true,name = "aadharNumber")
    private String aadharNumber;
    @Column(name = "numOfRooms")
    private int numOfRooms;
    @Column(name = "roomNumbers")
    private String roomNumbers;
    @Column(name = "roomPrice")
    private int roomPrice;
    @Column(name = "transactionId")
    private String transactionId="0";
    @Column(name = "createdOn")
    private LocalDate createdOn;


    public BookingInfoEntity(int bookingId, LocalDate fromDate, LocalDate toDate, String aadharNumber, int numOfRooms, String roomNumbers, int roomPrice, String transactionId, LocalDate createdOn) {
        this.bookingId = bookingId;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.aadharNumber = aadharNumber;
        this.numOfRooms = numOfRooms;
        this.roomNumbers = roomNumbers;
        this.roomPrice = roomPrice;
        this.transactionId = transactionId;
        this.createdOn = createdOn;;

    }




    public BookingInfoEntity() {

    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public int getNumOfRooms() {
        return numOfRooms;
    }

    public void setNumOfRooms(int numOfRooms) {
        this.numOfRooms = numOfRooms;
    }

    public String getRoomNumbers() {
        return roomNumbers;
    }

    public void setRoomNumbers(String roomNumbers) {
        this.roomNumbers = BookingServiceImpl.getRoomNumbers(numOfRooms);
    }

    public int getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(int roomPrice) {

//        System.out.println(stayDays);
//        System.out.println(fromDate);
//        System.out.println(toDate);
//        System.out.println((Object)toDate.getClass().getSimpleName());
        this.roomPrice = numOfRooms*1000*5;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public LocalDate getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDate createdOn) {
       System.out.println(java.time.LocalDate.now());
       System.out.println("hi");
        this.createdOn = java.time.LocalDate.now();

    }
    @Override
    public String toString() {
        return "BookingInfoEntity{" +
                "bookingId=" + bookingId +
                ", fromDate=" + fromDate +
                ", toDate=" + toDate +
                ", aadharNumber='" + aadharNumber + '\'' +
                ", numOfRooms=" + numOfRooms +
                ", roomNumbers='" + roomNumbers + '\'' +
                ", roomPrice=" + roomPrice +
                ", transactionId=" + transactionId +
                ", bookedOn=" + createdOn +
                '}';
    }
}