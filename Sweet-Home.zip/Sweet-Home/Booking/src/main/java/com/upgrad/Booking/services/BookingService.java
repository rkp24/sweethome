package com.upgrad.Booking.services;

import com.upgrad.Booking.Exception.BookingFailedException;
import com.upgrad.Booking.entities.BookingInfoEntity;
//import com.upgrad.Booking.entities.BookingInfoResponse;
import com.upgrad.Booking.entities.Error;
import com.upgrad.Booking.entities.PaymentInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BookingService {

//    public BookingInfoEntity createBooking(BookingInfoResponse roomBookingRequest) throws BookingFailedException;

    public BookingInfoEntity acceptBookingDetails(BookingInfoEntity bookingInfoEntity);

    public List<BookingInfoEntity> acceptMultipleBookingDetails(List<BookingInfoEntity> bookings);

    public BookingInfoEntity getBookingDetails(int id);

    public BookingInfoEntity updateBookingDetails(int id,BookingInfoEntity bookingInfoEntity);

    public boolean deleteBookingDetails(int id);

    public List<BookingInfoEntity> getAllBooking();

    public Page<BookingInfoEntity> getPaginatedBookingDetails(Pageable pageable);

    public BookingInfoEntity proceedpayment(int id, PaymentInfo paymentInfo) throws BookingFailedException, Exception, Error;

}
