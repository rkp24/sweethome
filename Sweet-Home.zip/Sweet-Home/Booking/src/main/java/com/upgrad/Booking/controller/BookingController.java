package com.upgrad.Booking.controller;


import com.upgrad.Booking.Exception.BookingFailedException;
import com.upgrad.Booking.dao.BookingDao;
import com.upgrad.Booking.dto.BookingDTO;
import com.upgrad.Booking.entities.BookingInfoEntity;
import com.upgrad.Booking.entities.Error;
import com.upgrad.Booking.entities.PaymentInfo;
import com.upgrad.Booking.services.BookingService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
//@RequestMapping("hotel_booking")
public class BookingController {

    @Autowired
    BookingService bookingService;

    @Autowired
    BookingDao bookingDao;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    public BookingController(BookingService bookingService)
    {
        this.bookingService=bookingService;

    }
//    @PostMapping(value="/movies", consumes = MediaType.APPLICATION_JSON_VALUE,
//            produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity createMovie(@RequestBody MovieDTO movieDTO){
//
//        //convert movieDTO to MovieEntity
//
//        Movie newMovie = modelMapper.map(movieDTO, Movie.class);
//        Movie savedMovie = movieService.acceptMovieDetails(newMovie);
//
//        MovieDTO savedMovieDto = modelMapper.map(savedMovie,MovieDTO.class);
//
//        return new ResponseEntity(savedMovieDto, HttpStatus.CREATED);
//
//    }


    @PostMapping(value = "/booking",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createBooking(@RequestBody BookingDTO bookingDTO){

        BookingInfoEntity newBooking=modelMapper.map(bookingDTO,BookingInfoEntity.class);

        BookingInfoEntity savedBooking=bookingService.acceptBookingDetails(newBooking);
        BookingDTO savedBookingDto=modelMapper.map(savedBooking,BookingDTO.class);
        return new ResponseEntity(savedBookingDto,HttpStatus.CREATED);

    }

//    @PostMapping("/booking_test")
//    @ResponseStatus(code = HttpStatus.CREATED)
//    public BookingInfoEntity bookingDetails(@RequestBody BookingInfoEntity bookingRequest) {
//     return bookingDao.save(bookingRequest);
//    }


    @GetMapping(value = "/getbooking",consumes = MediaType.APPLICATION_JSON_VALUE,produces =MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getAllBooking()
    {
        List<BookingInfoEntity> bookingInfoEntityList = bookingService.getAllBooking();
        List<BookingDTO> bookingDTOList=new ArrayList<>();

        for(BookingInfoEntity bookingInfoEntity : bookingInfoEntityList){
            bookingDTOList.add(modelMapper.map(bookingInfoEntity,BookingDTO.class));
        }
        return new ResponseEntity(bookingDTOList,HttpStatus.OK);
    }

//    @PutMapping(value = "booking/{id}",consumes = MediaType.APPLICATION_JSON_VALUE,produces =MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity updateBookingDetails(@PathVariable(name = "id")int id,@RequestBody BookingDTO bookingDTO){
//        BookingInfoEntity newBooking=modelMapper.map(bookingDTO,BookingInfoEntity.class);
//        BookingInfoEntity updateBooking=bookingService.updateBookingDetails(id,newBooking);
//        BookingDTO updatebookingDto =modelMapper.map(updateBooking,BookingDTO.class);
//        return new ResponseEntity(updatebookingDto,HttpStatus.OK);
//    }

//    @PostMapping("/booking/{bookingId}/transaction")
//    @ResponseStatus(code = HttpStatus.CREATED)
//    public BookingInfoEntity proceedPayment(@PathVariable int id,
//                                            @RequestBody PaymentInfo paymentInfo)
//            throws Exception, BookingFailedException, Error {
//         return bookingService.proceedpayment(id,paymentInfo);
//    }
}
